export interface ICreateBooking {
  adult_count: string;
  child_count: string;
  check_in: string;
  check_out: string;
  user_id: number;
  total_cost: string;
  hotel_id: number;
}
