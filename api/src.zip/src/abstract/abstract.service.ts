import Models from '../common/model/Models';

abstract class AbstractServices {
  protected models = new Models();
}

export default AbstractServices;
