export interface IDecoded {
  userId: number;
  iat: number;
  exp: number;
}
